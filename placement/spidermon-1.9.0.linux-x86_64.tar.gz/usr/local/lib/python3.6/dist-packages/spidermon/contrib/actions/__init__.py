from __future__ import absolute_import
from spidermon.templates import template_loader

template_loader.auto_discover("reports")
